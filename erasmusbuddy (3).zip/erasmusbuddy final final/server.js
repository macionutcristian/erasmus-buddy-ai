const express = require("express");
const multer = require("multer");
const cors = require("cors");

const app = express();
app.use(cors()); // ✅ Allows requests from different origins

// Set up storage for uploaded files
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, "uploads/"); // ✅ Ensure this folder exists
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + "-" + file.originalname);
    },
});
const upload = multer({ storage: storage });

// API route for file upload
app.post("/upload-endpoint", upload.single("document"), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ message: "No file uploaded!" });
    }
    res.json({ 
        message: "File uploaded successfully!", 
        filePath: req.file.filename 
    });
});

// Start server
const PORT = 5000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
