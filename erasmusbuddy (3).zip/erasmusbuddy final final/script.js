function handleLogin() {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    const errorMessage = document.getElementById("error-message");

    const storedUser = JSON.parse(localStorage.getItem(username));

    if (username === "admin" && password === "admin123") {
        localStorage.setItem("loggedInUser", "admin");
        window.location.href = "dashboard.html";
    } else if (storedUser && storedUser.password === password) {
        localStorage.setItem("loggedInUser", username);
        window.location.href = "dashboard.html";
    } else {
        errorMessage.textContent = "Incorrect username or password.";
    }
}

function handleSignup() {
    const userData = {
        username: document.getElementById("new-username").value,
        password: document.getElementById("new-password").value,
        fullName: document.getElementById("full-name").value,
        lastName: document.getElementById("last-name").value,
        nationality: document.getElementById("nationality").value,
        originUniversity: document.getElementById("origin-university").value,
        originCountry: document.getElementById("origin-country").value,
        destinationUniversity: document.getElementById("destination-university").value,
        destinationCountry: document.getElementById("destination-country").value,
        destinationCity: document.getElementById("destination-city").value,
    };

    if (
        !userData.username || !userData.password || !userData.fullName ||
        !userData.lastName || !userData.nationality || !userData.originUniversity ||
        !userData.originCountry || !userData.destinationUniversity ||
        !userData.destinationCountry || !userData.destinationCity
    ) {
        alert("Please fill in all fields.");
        return;
    }

    localStorage.setItem(userData.username, JSON.stringify(userData));
    alert("Account created successfully! You can now log in.");
    window.location.href = "index.html";
}

async function handleFileUpload(event) {
    event.preventDefault(); // ✅ Prevents page refresh

    let formData = new FormData(document.getElementById("uploadForm")); // ✅ Ensure correct formData reference
    
    try {
        let response = await fetch("http://localhost:5000/upload-endpoint", {
            method: "POST",
            body: formData
        });

        if (!response.ok) {
            throw new Error(`File upload failed. Status: ${response.status}`);
        }

        let result = await response.json();
        alert(result.message || "Upload successful!");

        // ✅ Store filename in localStorage so the chatbot can access it
        localStorage.setItem("uploadedFile", result.filePath);
        
    } catch (error) {
        console.error("Upload Error:", error);
        alert("Error uploading file: " + error.message);
    }
}

// ✅ Ensure this event listener is correctly attached
document.addEventListener('DOMContentLoaded', function() {
    let uploadForm = document.getElementById('uploadForm');
    if (uploadForm) {
        uploadForm.addEventListener('submit', handleFileUpload);
    }
});

document.addEventListener('DOMContentLoaded', function() {
    let uploadForm = document.getElementById('uploadForm');
    if (uploadForm) {
        uploadForm.addEventListener('submit', handleFileUpload);
    }
});