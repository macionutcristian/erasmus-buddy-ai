// "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"

let chatHistory = [];

document.addEventListener("DOMContentLoaded", () => {
    console.log("Chat interface loaded successfully!");

    const userInput = document.getElementById("user-input");
    const sendButton = document.getElementById("send-button");

    // Handle Enter key press to send message
    userInput.addEventListener("keypress", function (e) {
        if (e.key === "Enter") {
            e.preventDefault(); // Prevent line break
            sendToChatGPT();
        }
    });

    // Handle button click to send message
    if (sendButton) {
        sendButton.addEventListener("click", sendToChatGPT);
    }

    const dropArea = document.getElementById("drop-area");
    if (dropArea) {
        dropArea.addEventListener("dragover", (e) => {
            e.preventDefault();
            dropArea.style.background = "#e1e1e1";
        });

        dropArea.addEventListener("dragleave", () => {
            dropArea.style.background = "white";
        });

        dropArea.addEventListener("drop", (e) => {
            e.preventDefault();
            dropArea.style.background = "white";
            const file = e.dataTransfer.files[0];
            handleFileUpload(file);
        });
    }
});

async function sendToChatGPT() {
    const userInput = document.getElementById("user-input");
    const responseField = document.getElementById("chatgpt-response");
    const userMessage = userInput.value.trim();

    if (!userMessage) return;

    chatHistory.push({ role: "user", content: userMessage });
    updateChatUI();
    userInput.value = "";

    let uploadedFile = localStorage.getItem("uploadedFile");
    let fileMessage = uploadedFile ? `User uploaded: ${uploadedFile}` : "";

    const typingMessage = document.createElement("div");
    typingMessage.classList.add("chat-message", "bot-message");
    typingMessage.textContent = "AI-smus is thinking...";
    responseField.appendChild(typingMessage);

    const API_KEY = "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";

    try {
        const response = await fetch("https://api.openai.com/v1/chat/completions", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${API_KEY}`
            },
            body: JSON.stringify({
                model: "gpt-4",
                messages: [
                    { role: "system", content: "You assist students in filling Erasmus documents based on uploaded files." },
                    { role: "user", content: fileMessage },  // ✅ Ensure file path is passed
                    ...chatHistory
                ],
                max_tokens: 600,
                temperature: 0.5,
                top_p: 0.9,
                frequency_penalty: 0.5,
                presence_penalty: 0.5,
                stop: ["END"]
            })
        });

        const data = await response.json();
        responseField.removeChild(typingMessage);

        if (data.choices && data.choices.length > 0) {
            const botMessage = formatMessage(data.choices[0].message.content.trim());
            chatHistory.push({ role: "assistant", content: botMessage });
            updateChatUI();
        } else {
            throw new Error("No response from API");
        }
    } catch (error) {
        responseField.removeChild(typingMessage);
        responseField.innerHTML += "<p class='bot-message error'>⚠️ Error: Unable to fetch response.</p>";
    }
}


function updateChatUI() {
    const responseField = document.getElementById("chatgpt-response");
    responseField.innerHTML = "";

    chatHistory.forEach(message => {
        const messageDiv = document.createElement("div");
        messageDiv.classList.add("chat-message", message.role === "user" ? "user-message" : "bot-message");
        messageDiv.innerHTML = message.content;
        responseField.appendChild(messageDiv);
    });
}

function handleFileUpload(file) {
    if (!file) return;

    const reader = new FileReader();

    reader.onload = function (event) {
        const fileContent = event.target.result;

        localStorage.setItem("uploadedFile", fileContent); // ✅ Store extracted text

        const fileMessage = document.createElement("div");
        fileMessage.classList.add("chat-message", "user-message");
        fileMessage.textContent = `📎 Uploaded: ${file.name}`;
        document.getElementById("chatgpt-response").appendChild(fileMessage);

        chatHistory.push({ role: "user", content: `User uploaded: ${file.name}.\nExtracted content:\n${fileContent}` });
        updateChatUI();
    };

    reader.readAsText(file); // ✅ Read file as text
}


function formatMessage(message) {
    return message
        .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>") // Bold text
        .replace(/\n/g, "<br>") // Line breaks
        .replace(/(\d+)\.\s/g, "<br><strong>$1.</strong> "); // Numbered lists
}
